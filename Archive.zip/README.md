1.You should have PostgresSQl downloaded
2.You should config a .env file as shown in example-env.txt
3.Don't forget to download requirements
4.Don't forget to migrate
5.For the custom admin interface give staff access to a user
6.Admins can only be created via manual ways